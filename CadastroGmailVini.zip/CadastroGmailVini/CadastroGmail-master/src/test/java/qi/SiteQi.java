package qi;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class SiteQi {


        static WebDriver driver;

        public SiteQi(WebDriver driver) {

            this.driver = driver;
        }

        public void preencherCampoSiteQi() {

            WebElement nome = driver.findElement(By.id("form-field-nome"));
            nome.sendKeys("Vini Santos");

            WebElement email = driver.findElement(By.id("form-field-email"));
            email.sendKeys("vinicius370305@gmail.com");

            WebElement telefone = driver.findElement(By.id("form-field-telefone"));
            telefone.sendKeys("51981553310");

            WebElement cpf = driver.findElement(By.id("form-field-cpf"));
            cpf.sendKeys("85367249000");

            WebElement cidade = driver.findElement(By.id("form-field-cidade"));
            Select objCidade = new Select(driver.findElement(By.id("form-field-cidade")));
            objCidade.selectByVisibleText("Alvorada");

            WebElement solicitacao = driver.findElement(By.id("form-field-solicitacao"));
            Select objSolicitacao = new Select(driver.findElement(By.id("form-field-solicitacao")));
            objSolicitacao.selectByVisibleText("Solicitação");

            WebElement mensagem = driver.findElement(By.id("form-field-mensagem"));
            mensagem.sendKeys("Opaaaaaaaaa!\n" +
                    "\n" +
                    "AEEEE deu bom o meu teste de automação.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "TMJ\n" +
                    "\n" +
                    "Segue no insta V1ni_s.\n");

            WebElement btAvancar = driver.findElement(By.xpath("//span[contains(text(),'Pronto, quero enviar a mensagem')]"));
            btAvancar.click();

        }
    }



